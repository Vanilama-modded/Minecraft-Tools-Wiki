# Minecraft Tools

| Generator Type | Description | Links | prize |
| --- | --- | --- | --- |
| Command Generators | generate a personalized custom command | 1. [https://mcstacker.net/](https://mcstacker.net/)
2. [https://gamergeeks.net](https://gamergeeks.net)  | Free |
| Block Display Engine | like Blender but for block and item displays | 1. [https://bdengine.app/](https://bdengine.app/)
2. [https://eszesbalint.github.io/bdstudio/editor](https://eszesbalint.github.io/bdstudio/editor)
3. [https://www.gamergeeks.net/apps/minecraft/block-display-command-generator](https://www.gamergeeks.net/apps/minecraft/block-display-command-generator)
4. [https://misode.github.io/transformation/](https://misode.github.io/transformation/) | Free |
| Structure/biome finding | find a structure in your world by just inputting the world seed and choosing the right version | 1. [https://www.chunkbase.com/apps/seed-map#seed=-2515391033078911427&platform=java_1_21_5&dimension=overworld&x=0&z=0&zoom=0.5](https://www.chunkbase.com/apps/seed-map#seed=-2515391033078911427&platform=java_1_21_5&dimension=overworld&x=0&z=0&zoom=0.5) | Free |
| Minecraft map gen. | upload a picture and turn it into a map | 1. [https://mc-map.djfun.de/](https://mc-map.djfun.de/) | Free |
| Minecraft armor stand  | make a personalized command for a armor stand customized how you want | 1. [https://haselkern.com/Minecraft-ArmorStand/](https://haselkern.com/Minecraft-ArmorStand/) | Free |
| .OBJ to Schematic | turn any obj file into a worldedit, litematica, etc. schematic | 1. [https://objtoschematic.com/](https://objtoschematic.com/) | Free |
| [c](https://docs.papermc.io/misc/tools/item-command-converter)ommand updater | update a command from any version to the latest version | 1. [https://docs.papermc.io/misc/tools/item-command-converter](https://docs.papermc.io/misc/tools/item-command-converter) | Free |
| Wiki | all the info you need in Vanilla Minecraft | 1. [https://minecraft.wiki/](https://minecraft.wiki/)
2. [https://minecraft.fandom.com/wiki/Minecraft_Wiki](https://minecraft.fandom.com/wiki/Minecraft_Wiki) (Not Recommended please use the first wiki)
3. [https://datapack.wiki/](https://datapack.wiki/) | Free |
| Minecraft Tools | some tools from the Minecraft tools website. (For any of the there generated commands to use in the latest version use the command updater) | 1. [https://minecraft.tools/en/custom-crafting.php](https://minecraft.tools/en/custom-crafting.php)
2. [https://minecraft.tools/en/firework.php](https://minecraft.tools/en/firework.php)
3. [https://minecraft.tools/en/spawn.php](https://minecraft.tools/en/spawn.php)
4. [https://minecraft.tools/en/enchant.php](https://minecraft.tools/en/enchant.php)
5. [https://minecraft.tools/en/banner.php](https://minecraft.tools/en/banner.php)
6. [https://minecraft.tools/en/crafting.php](https://minecraft.tools/en/crafting.php)
7. [https://minecraft.tools/en/color-code.php](https://minecraft.tools/en/color-code.php)
8. [https://minecraft.tools/en/skin.php](https://minecraft.tools/en/skin.php)
9. [https://minecraft.tools/en/armor.php](https://minecraft.tools/en/armor.php)
10. [https://minecraft.tools/en/beacon-color.php](https://minecraft.tools/en/beacon-color.php)
11. [https://minecraft.tools/en/title.php](https://minecraft.tools/en/title.php)
12. [https://minecraft.tools/en/sign.php](https://minecraft.tools/en/sign.php)
13. [https://minecraft.tools/en/book.php](https://minecraft.tools/en/book.php)
14. [https://minecraft.tools/en/tellraw.php](https://minecraft.tools/en/tellraw.php)
15. [https://minecraft.tools/en/potion.php](https://minecraft.tools/en/potion.php)
16. [https://minecraft.tools/en/shield.php](https://minecraft.tools/en/shield.php)
17. [https://minecraft.tools/en/loots.php](https://minecraft.tools/en/loots.php) | Free |
| CraftMc | The most important tools from the CraftMC Website | 1. [https://www.craftmc.net/tools/circle-generator-for-minecraft](https://www.craftmc.net/tools/circle-generator-for-minecraft)
2.  [https://www.craftmc.net/tools/minecraft-redstone-circuit-designer](https://www.craftmc.net/tools/minecraft-redstone-circuit-designer)
3. [https://www.craftmc.net/tools/resource-pack-merger](https://www.craftmc.net/tools/resource-pack-merger)
4. [https://www.craftmc.net/tools/minecraft-skin-editor](https://www.craftmc.net/tools/minecraft-skin-editor)
5. [https://www.craftmc.net/tools/minecraft-nbt-editor](https://www.craftmc.net/tools/minecraft-nbt-editor)
6. [https://www.craftmc.net/tools/minecraft-command-generator?tab=villager-trade](https://www.craftmc.net/tools/minecraft-command-generator?tab=villager-trade)
7. [https://www.craftmc.net/tools/speech-bubbles](https://www.craftmc.net/tools/speech-bubbles)
8. [https://www.craftmc.net/tools/minecraft-potion-brewing-guide](https://www.craftmc.net/tools/minecraft-potion-brewing-guide)
9. [https://www.craftmc.net/tools/bedrock-to-java-converter](https://www.craftmc.net/tools/bedrock-to-java-converter) | Free |
| SkinMC   | Some of the important SkinMc tools | 1. [https://skinmc.net/banner/gallery](https://skinmc.net/banner/gallery)
2. [https://skinmc.net/totem](https://skinmc.net/totem)
3. [https://skinmc.net/avatars](https://skinmc.net/avatars)
4. [https://skinmc.net/achievement](https://skinmc.net/achievement)
5. [https://skinmc.net/skin-editor](https://skinmc.net/skin-editor) | Free |
| Minecraft Heads | A gallery of different player heads | 1. [https://minecraft-heads.com/](https://minecraft-heads.com/)
2. [https://skinmc.net/heads](https://skinmc.net/heads) | Free |
| Minecraft Bedrock Creator | Minecraft bedrock tool for creating addons and stuff | 1. [https://mctools.dev/](https://mctools.dev/) | Free |
| Enchanting | Most efficient way to enchant stuff | 1. [https://iamcal.github.io/enchant-order/](https://iamcal.github.io/enchant-order/) | Free |
| World tool | convert & edit worlds | [1. https://www.universalminecrafttool.com/](https://www.universalminecrafttool.com/) | Freemium |
| Minecraft Server Tools & and more | tools mostly focused around servers  | 1. [https://mctools.org/](https://mctools.org/)
2.[https://playit.gg/](https://playit.gg/) ([tunneling explained](https://www.wikiwand.com/en/articles/Tunneling_protocol)) | Free |
| Minecraft Shape builder | a step by step guide on how to build complicated shapes | 1. [https://www.plotz.co.uk/plotz-model.php?model=Ellipsoid](https://www.plotz.co.uk/plotz-model.php?model=Ellipsoid) | Free |
| misode | some useful tools for making datapacks | 1. [https://misode.github.io/loot-table/](https://misode.github.io/loot-table/)
2. [https://misode.github.io/advancement/](https://misode.github.io/advancement/)
3. [https://misode.github.io/recipe/](https://misode.github.io/recipe/)
4. [https://misode.github.io/worldgen/](https://misode.github.io/worldgen/)
5. [https://misode.github.io/damage-type/](https://misode.github.io/damage-type/)
6. [https://misode.github.io/convert/](https://misode.github.io/convert/)
7.[https://misode.github.io/customized/?tab=basic](https://misode.github.io/customized/?tab=basic)
8. [https://misode.github.io/template-placer/](https://misode.github.io/template-placer/)
9. [https://misode.github.io/transformation/](https://misode.github.io/transformation/)
10. [https://misode.github.io/partners/](https://misode.github.io/partners/) (modded generators) 
11. [https://misode.github.io/generators/](https://misode.github.io/generators/) (all generators) | Free |
| Minecraft science | another Minecraft tools website | 1. [https://minecraftcommand.science/en/tool-generator](https://minecraftcommand.science/en/tool-generator) | Free |
| Easy Map Updater | update all commands in a world to the latest version | 1. [https://github.com/StickyPiston-Hosting/Easy-Map-Updater](https://github.com/StickyPiston-Hosting/Easy-Map-Updater) | Free |
| McAssets | a library for every Minecraft asset | 1. [https://mcasset.cloud/](https://mcasset.cloud/) | Free |
| Weld | fastest data & resource pack merger | 1. [https://weld.smithed.dev/](https://weld.smithed.dev/) | Free |
| Resource packs, datapacks, mods, etc. | upload or download resource packs, datapacks, mods and more | 1. [https://www.planetminecraft.com/](https://www.planetminecraft.com/)
2. [https://modrinth.com/](https://modrinth.com/)
3. [https://www.curseforge.com/minecraft/search?page=1&pageSize=20&sortBy=relevancy](https://www.curseforge.com/minecraft/search?page=1&pageSize=20&sortBy=relevancy) | Free |
| Creator Websites

 (work in Progress. Taking recommendations in) | The websites of Minecraft content creators  | 1.[https://ijaminecraft.com/en/creations](https://ijaminecraft.com/en/creations)
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.
21.
22.
23.
24.
25.
26. | Free & Paid |
| Server hosting | Different server Hosts | 1.[https://www.bisecthosting.com/](https://www.bisecthosting.com/)
2.[https://server.nitrado.net/](https://server.nitrado.net/)
3.[https://play.hosting](https://play.hosting/)/ (Free)
4.[https://aternos.org/:en/](https://aternos.org/:en/) (Free)
5.[https://modrinth.com/servers](https://modrinth.com/servers)
6.[https://scalacube.com/de/free/minecraft/server/hosting](https://scalacube.com/de/free/minecraft/server/hosting) (Free & Paid)
7.[https://mine-hoster.de/](https://mine-hoster.de/)
8.[https://www.g-portal.com/de](https://www.g-portal.com/de)
9.[https://minefort.com/](https://minefort.com/)
10.[https://app.minehut.com/dashboard/home](https://app.minehut.com/dashboard/home) **(Free)**
11.[https://apexminecrafthosting.com/de/](https://apexminecrafthosting.com/de/)
12.[https://shockbyte.com/de](https://shockbyte.com/de)
13.[https://pebblehost.com/](https://pebblehost.com/)
14.[https://www.minecraft.net/de-de/download/server](https://www.minecraft.net/de-de/download/server) **(Selfhost, Free)**
15.[https://freemcserver.net/](https://freemcserver.net/) (Free)
16.[https://falixnodes.net/free-minecraft-server-hosting](https://falixnodes.net/free-minecraft-server-hosting) (Free)
17.[https://axenthost.com/de/games/minecraft/](https://axenthost.com/de/games/minecraft/) (Free)
18. [https://godlike.host/de/](https://godlike.host/de/)
19.[https://server.pro/](https://server.pro/)
20.[https://wisehosting.com/](https://wisehosting.com/)
21.[https://dathost.net/minecraft-server-hosting](https://dathost.net/minecraft-server-hosting)
22.[https://www.hostinger.com/de/tutorials/minecraft-server-erstellen](https://www.hostinger.com/de/tutorials/minecraft-server-erstellen)
23.[https://minekeep.net/](https://minekeep.net/) (Free)
24.[https://instanthost.gg/de](https://instanthost.gg/de)
25.[https://ggservers.com/](https://ggservers.com/)
26.[https://nodecraft.com/games/minecraft-server-hosting](https://nodecraft.com/games/minecraft-server-hosting)
27.[https://gamerunner.com/minecraft-server](https://gamerunner.com/minecraft-server) (Free) | Free, paid & Freemium |

[Vanilama](Vanilama%201d3e05b9ba6e80b8851aff180954bf71.md)

[Silabear](Silabear%201d3e05b9ba6e805fb3dde0c9ce844cb1.md)